package com.example.cv19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Dettagli extends AppCompatActivity {

    TextView testo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dettagli);

        String nome = getIntent().getStringExtra("nomeHotel");
        testo = (TextView)findViewById(R.id.textTesto);
        testo.setText(nome);
    }
}