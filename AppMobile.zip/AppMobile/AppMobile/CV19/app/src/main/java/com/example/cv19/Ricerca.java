package com.example.cv19;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Ricerca extends AppCompatActivity {
    TextView tv;
    ProgressDialog progressDialog;
    ConnectionClass connectionClass;
    ResultSet rs;
    Button b;
    String ricerca;
    String nomeHotel="";
    ListView lv;
    ArrayList<String> listaStrutture=new ArrayList<>();;
    ArrayAdapter<String> adapter;
    Button newbtn;
    LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ricerca);

        getSupportActionBar().hide();

        ricerca = getIntent().getStringExtra("ricerca");
        lv=(ListView)findViewById(R.id.listView1);
        tv = (TextView) findViewById(R.id.textView44);
        tv.setText(ricerca);
        b=(Button)findViewById(R.id.buttonCerca1);

        connectionClass = new ConnectionClass();
        listaStrutture.add("Nome            Prezzo");

        b.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                RicercaCrud list = new RicercaCrud();
                list.execute("");
                lv.setAdapter(adapter);
                addButton();
            }
        });

        adapter=new ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line, android.R.id.text1,listaStrutture);

    }

    public void addButton(){
        layout = (LinearLayout)findViewById(R.id.mainLayout);
        newbtn = new Button(this);
        newbtn.setText("Dettagli");
        layout.addView(newbtn);
    }

    public void openNew(String nomeHotel){
        Intent intent = new Intent(this, Dettagli.class);
        intent.putExtra("nomeHotel", nomeHotel);
        startActivity(intent);

    }


    public void riempiLista(){
        //ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,listaStrutture);
    }

    public class RicercaCrud extends AsyncTask<String, String, ArrayList<String>> {

        String z = "";

        @Override
        protected void onPreExecute(){
        }

        @Override
        protected ArrayList<String> doInBackground(String... params){
            try{
                Connection con = connectionClass.CONN();
                //controlli sulla connessione
                if(con == null){
                    z = "Controlla la connessione ad internet...";
                }else{
                    String query = "select * from strutture where citta= '"+ricerca+"' ";
                    Statement stat = con.createStatement();
                    rs=stat.executeQuery(query);
                    while(rs.next()){
                        nomeHotel=rs.getString("nome")+"                 "+ rs.getString("tariffa") +"€";
                        listaStrutture.add(nomeHotel);
                        done();

                    }
                    z=" avvenuta con successo";
                }
            }catch (Exception ex){
                z = "Exception: " + ex;
            }
            return listaStrutture;
        }
        @Override
        protected void onPostExecute(ArrayList<String> z){




        }

        public void done(){
            newbtn.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){

                    openNew(nomeHotel);
                }
            });
        }
    }
}